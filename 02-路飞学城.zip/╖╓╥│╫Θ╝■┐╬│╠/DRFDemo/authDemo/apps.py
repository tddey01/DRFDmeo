from django.apps import AppConfig


class AuthdemoConfig(AppConfig):
    name = 'authDemo'
