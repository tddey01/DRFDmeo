from django.apps import AppConfig


class PagedemoConfig(AppConfig):
    name = 'pageDemo'
