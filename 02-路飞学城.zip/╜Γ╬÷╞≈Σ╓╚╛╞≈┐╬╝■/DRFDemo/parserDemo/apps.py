from django.apps import AppConfig


class ParserdemoConfig(AppConfig):
    name = 'parserDemo'
