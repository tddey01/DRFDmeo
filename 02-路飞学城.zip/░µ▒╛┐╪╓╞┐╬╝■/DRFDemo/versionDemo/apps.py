from django.apps import AppConfig


class VersiondemoConfig(AppConfig):
    name = 'versionDemo'
