from django.apps import AppConfig


class SerdemoConfig(AppConfig):
    name = 'SerDemo'
